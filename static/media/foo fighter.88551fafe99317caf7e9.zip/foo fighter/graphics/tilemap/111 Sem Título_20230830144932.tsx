<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="111 Sem Título_20230830144932" tilewidth="16" tileheight="16" tilecount="476" columns="28">
 <image source="D:/Downloads/MyFlow/111 Sem Título_20230830144932.png" width="448" height="272"/>
</tileset>
