<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="128" tileheight="128" tilecount="15" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="D:/Downloads/MyFlow/tree.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="D:/Downloads/MyFlow/tree2.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="D:/Downloads/MyFlow/wagon.png"/>
 </tile>
 <tile id="3">
  <image width="16" height="16" source="D:/Downloads/MyFlow/boss.png"/>
 </tile>
 <tile id="4">
  <image width="16" height="16" source="D:/Downloads/MyFlow/fire.png"/>
 </tile>
 <tile id="5">
  <image width="16" height="16" source="D:/Downloads/MyFlow/fire_boss.png"/>
 </tile>
 <tile id="6">
  <image width="16" height="16" source="D:/Downloads/MyFlow/fire_skeleton.png"/>
 </tile>
 <tile id="7">
  <image width="16" height="32" source="D:/Downloads/MyFlow/grave.png"/>
 </tile>
 <tile id="8">
  <image width="16" height="16" source="D:/Downloads/MyFlow/invisible.png"/>
 </tile>
 <tile id="9">
  <image width="16" height="16" source="D:/Downloads/MyFlow/player.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="D:/Downloads/MyFlow/rock.png"/>
 </tile>
 <tile id="11">
  <image width="16" height="16" source="D:/Downloads/MyFlow/skeleton.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="32" source="D:/Downloads/MyFlow/statue.png"/>
 </tile>
 <tile id="13">
  <image width="128" height="128" source="../objects/09.png"/>
 </tile>
 <tile id="14">
  <image width="64" height="80" source="D:/Downloads/MyFlow/115 Sem Título_20230901021624.png"/>
 </tile>
</tileset>
