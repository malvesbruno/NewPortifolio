<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TilesetRelief" tilewidth="16" tileheight="16" tilecount="240" columns="20">
 <image source="D:/Downloads/NinjaAdventure/Backgrounds/Tilesets/TilesetRelief.png" width="320" height="192"/>
</tileset>
