<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TilesetFloorDetail" tilewidth="16" tileheight="16" tilecount="80" columns="16">
 <image source="D:/Downloads/NinjaAdventure/Backgrounds/Tilesets/TilesetFloorDetail.png" width="256" height="80"/>
</tileset>
